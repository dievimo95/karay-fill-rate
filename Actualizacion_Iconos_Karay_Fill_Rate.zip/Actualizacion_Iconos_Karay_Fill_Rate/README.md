# Actualización de pestañas — Karay Fill Rate

Esta actualización cambia únicamente los nombres e iconos del menú:

- 📦 Procesar pedidos
- 🕘 Histórico
- 📊 Indicadores

Para instalarla, reemplaza solamente `app.py` en el repositorio de Karay Fill Rate. La base de datos, usuarios, forecast e historial no se modifican.
